package com.codelovely.thecooksnook;

public class portionsAdapter {

}
